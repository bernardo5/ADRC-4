to compile:
1- make clean
2 - make


to run:
./main <file name>
